package com.cg.hcs.exception;

@SuppressWarnings("serial")
public class PatientException extends Exception {
	public PatientException(){
		
	}
	
	public PatientException(String message){
		super(message);
	}
	
	

}
