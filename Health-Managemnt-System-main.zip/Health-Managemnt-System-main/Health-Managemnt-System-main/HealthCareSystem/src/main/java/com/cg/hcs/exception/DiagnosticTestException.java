package com.cg.hcs.exception;

@SuppressWarnings("serial")
public class DiagnosticTestException extends Exception {
	public DiagnosticTestException() {
		
	}
	
	public DiagnosticTestException(String message) {
		super(message);
	}
	
}
