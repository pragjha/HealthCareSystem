package com.cg.hcs.exception;

@SuppressWarnings("serial")
public class UserException extends Exception {
	public UserException() {
		// TODO Auto-generated constructor stub
	}
	public UserException(String str) {
		super (str);
	}


}
