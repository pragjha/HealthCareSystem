package com.cg.hcs.exception;

@SuppressWarnings("serial")
public class TestResultException extends Exception {
	public TestResultException() {
	}
	public TestResultException(String message) {
		super(message);
		
	}
}
