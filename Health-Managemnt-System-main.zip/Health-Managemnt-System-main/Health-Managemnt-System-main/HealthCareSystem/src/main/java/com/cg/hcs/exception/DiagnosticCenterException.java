package com.cg.hcs.exception;

@SuppressWarnings("serial")
public class DiagnosticCenterException extends Exception {
	public DiagnosticCenterException() {
		// TODO Auto-generated constructor stub
	}
	public DiagnosticCenterException(String str) {
		super(str);
	}
}
