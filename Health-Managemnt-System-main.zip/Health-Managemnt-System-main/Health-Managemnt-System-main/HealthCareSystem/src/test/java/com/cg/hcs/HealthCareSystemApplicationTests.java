package com.cg.hcs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthCareSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
