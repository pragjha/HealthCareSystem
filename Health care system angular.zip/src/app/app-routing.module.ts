import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddAppointmentComponent } from './appointment/add-appointment/add-appointment.component';
import { AddCenterToAppointmentComponent } from './appointment/add-center-to-appointment/add-center-to-appointment.component';
import { AddTestToAppointmentComponent } from './appointment/add-test-to-appointment/add-test-to-appointment.component';
import { ViewAllAppointmentsComponent } from './appointment/view-all-appointments/view-all-appointments.component';
import { ViewAllDetailsComponent } from './appointment/view-all-details/view-all-details.component';
import { AddNewCenterComponent } from './diagnostic-center/add-new-center/add-new-center.component';
import { ModifyCenterComponent } from './diagnostic-center/modify-center/modify-center.component';
import { ViewAllDiagnosticCentersComponent } from './diagnostic-center/view-all-diagnostic-centers/view-all-diagnostic-centers.component';
import { ViewAllTestInACenterComponent } from './diagnostic-center/view-all-test-in-acenter/view-all-test-in-acenter.component';
import { ModifyTestComponent } from './diagnostic-test/modify-test/modify-test.component';
import { ViewAllDiagnosticTestsComponent } from './diagnostic-test/view-all-diagnostic-tests/view-all-diagnostic-tests.component';
import { BookAppointmentForAPatientComponent } from './patient/book-appointment-for-apatient/book-appointment-for-apatient.component';
import { RegisterPatientComponent } from './patient/register-patient/register-patient.component';
import { ViewAllTestResultsByPatientComponent } from './patient/view-all-test-results-by-patient/view-all-test-results-by-patient.component';
import { ViewAppointsmentsOfAPatientComponent } from './patient/view-appointsments-of-apatient/view-appointsments-of-apatient.component';
import { AddTestResultComponent } from './test-result/add-test-result/add-test-result.component';
import { ModifyTestResultComponent } from './test-result/modify-test-result/modify-test-result.component';
import { ViewAllTestResultComponent } from './test-result/view-all-test-result/view-all-test-result.component';
import { LoginUserComponent } from './user/login-user/login-user.component';
import { SigninUserComponent } from './user/signin-user/signin-user.component';

const routes: Routes = [
  {
    path:"",
    component:SigninUserComponent
  },
  {
    path:"login",
    component:LoginUserComponent
  },
  {
    path:"viewAllAppointments",
    component:ViewAllAppointmentsComponent
  },
  {
    path:"viewAllDiagnosticCenters",
    component:ViewAllDiagnosticCentersComponent
  },
  {
    path:"viewAllTests",
    component:ViewAllDiagnosticTestsComponent
  },
  {
    path:"addAppointment",
    component:AddAppointmentComponent
  },
  {
    path:"addCenterToAppointment/:id",
    component:AddCenterToAppointmentComponent
  },
  {
    path:"addTestToAppointment/:id",
    component:AddTestToAppointmentComponent
  },
  {
    path:"viewAllTest/:id",
    component:ViewAllTestInACenterComponent
  },
  {
    path:"modifyTest/:id",
    component:ModifyTestComponent
  },
  {
    path:"modifyCenter/:id",
    component:ModifyCenterComponent
  },
  {
    path:"addDiagnosticCenter",
    component:AddNewCenterComponent
  },
  {
    path:"viewAppointmentDetails/:id",
    component:ViewAllDetailsComponent
  },
  {
    path:"addTestResult/:id",
    component:AddTestResultComponent
  },
  {
    path:"modifyTestResult/:id",
    component:ModifyTestResultComponent
  },
  {
    path:"registerPatient",
    component:RegisterPatientComponent
  },
  {
    path:"bookAppointment/:id",
    component:BookAppointmentForAPatientComponent
  },
  {
    path:"viewAppointmentsOfPatient",
    component:ViewAppointsmentsOfAPatientComponent
  },
  {
    path:"viewTestResult",
    component:ViewAllTestResultsByPatientComponent
  },
  {
    path:"viewAllTestResult",
    component:ViewAllTestResultComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
