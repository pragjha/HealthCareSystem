import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Patient } from 'src/assets/Patient';
import { TestResult } from 'src/assets/TestResult';

@Injectable({
  providedIn: 'root'
})
export class TestResultService {

  url:string="http://localhost:9091/testResult";
  
  constructor(private h:HttpClient) { }
    addTestResult(id:number,tr:TestResult):Observable<any>{
      return this.h.post<any>(this.url+"/"+id+"/addTestResult/",tr,{responseType:'json'});
    }

    updateTestResult(tr:TestResult):Observable<any>{
      return this.h.put(this.url+"/updateResult/",tr,{responseType:'json'});
    }

    removeTestResult(id:number):Observable<any>{
      return this.h.delete(this.url+"/removeTestResult/"+id);
    }

    viewResultByPatient(id:number):Observable<any>{
      return this.h.get<any>(this.url+"/viewResultsByPatient/"+id);
    }

    getResultById(id:number):Observable<any>{
      return this.h.get<any>(this.url+"/getResult/"+id);
    }

    getAllTestResults():Observable<any>{
      return this.h.get<any>(this.url+"/viewAllTestResult");
    }
}
