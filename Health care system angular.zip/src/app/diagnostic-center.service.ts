import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DiagnosticCenter } from 'src/assets/DiagnosticCenter';
import { DiagnosticTest } from 'src/assets/DiagnosticTest';

@Injectable({
  providedIn: 'root'
})
export class DiagnosticCenterService {

  url:string="http://localhost:9091/center";

  constructor(private h:HttpClient) { }

  getAllDiagnosticCenters():Observable<any>{
    return this.h.get<any>(this.url+"/getCenters");
  }

  addCenter(c:DiagnosticCenter):Observable<any>{
    return this.h.post(this.url+"/addCenter",c,{responseType:'json'});
  }

  addCenterToAnAppointment(c:DiagnosticCenter,id:number):Observable<any>{
    return this.h.post(this.url+"/"+id+"/addCenter",c,{responseType:'json'});
  }

  getDiagnosticCenterById(id:number):Observable<any>{
    return this.h.get<any>(this.url+"/getCenter/"+id);
  }

  updateDiagnosticCenter(c:DiagnosticCenter):Observable<any>{
    return this.h.put(this.url+"/modifyCenter",c,{responseType:'json'});
  }

  viewTestDetails(id:number,name:string):Observable<any>{
    return this.h.get(this.url+"/testDetail/"+id+"/"+name);
  }

  addTest(id:number,t:DiagnosticTest):Observable<any>{
    return this.h.post(this.url+"/addTest/"+id,t,{responseType:'json'});
  }

  getDiagnosticCenter(name:string):Observable<any>{
    return this.h.get<any>(this.url+"/getCenterByName/"+name);
  }

  removeDiagnosticCenter(id:number):Observable<any>{
    return this.h.delete(this.url+"/removeCenter/"+id);
  }

  getListOfAppointments(name:string):Observable<any>{
    return this.h.get<any>(this.url+"/getAppointmentsByCenter/"+name);
  }
}
