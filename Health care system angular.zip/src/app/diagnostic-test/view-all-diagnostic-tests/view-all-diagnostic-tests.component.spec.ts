import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAllDiagnosticTestsComponent } from './view-all-diagnostic-tests.component';

describe('ViewAllDiagnosticTestsComponent', () => {
  let component: ViewAllDiagnosticTestsComponent;
  let fixture: ComponentFixture<ViewAllDiagnosticTestsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAllDiagnosticTestsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAllDiagnosticTestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
