import { Component, OnInit } from '@angular/core';
import { DiagnosticTestService } from 'src/app/diagnostic-test.service';
import { DiagnosticTest } from 'src/assets/DiagnosticTest';

@Component({
  selector: 'app-view-all-diagnostic-tests',
  templateUrl: './view-all-diagnostic-tests.component.html',
  styleUrls: ['./view-all-diagnostic-tests.component.css']
})
export class ViewAllDiagnosticTestsComponent implements OnInit {

  diagnostictests:DiagnosticTest[]=[];
  constructor(private h:DiagnosticTestService) {
    this.h.getAllTest().subscribe(a=>this.diagnostictests=a);
   }

  ngOnInit(): void {
  }
}
