import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewAllDiagnosticTestsComponent } from './view-all-diagnostic-tests/view-all-diagnostic-tests.component';
import { ModifyTestComponent } from './modify-test/modify-test.component';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [ViewAllDiagnosticTestsComponent, ModifyTestComponent],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports:[
    ViewAllDiagnosticTestsComponent, ModifyTestComponent
  ]
})
export class DiagnosticTestModule { }
