import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DiagnosticTestService } from 'src/app/diagnostic-test.service';
import { DiagnosticTest } from 'src/assets/DiagnosticTest';
import { Location } from '@angular/common'
import { TestService } from 'src/app/test.service';

@Component({
  selector: 'app-modify-test',
  templateUrl: './modify-test.component.html',
  styleUrls: ['./modify-test.component.css']
})
export class ModifyTestComponent implements OnInit {

  test:DiagnosticTest=new DiagnosticTest();
  id:number;
  constructor(private s:DiagnosticTestService,private r:Router,
    private route:ActivatedRoute,private lo:Location,
    private t:TestService) {
    this.id=parseInt(this.route.snapshot.paramMap.get("id"));
    this.t.getTestById(this.id).subscribe(a=>this.test=a);
   }

  ngOnInit(): void {
  }
  modifyTest():void{
    this.s.updateTestDetail(this.test).subscribe(t=>this.test=t);
    this.lo.back();
  }

}
