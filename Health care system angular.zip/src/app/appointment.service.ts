import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Appointment } from 'src/assets/Appointment';

@Injectable({
  providedIn: 'root'
})
export class AppointmentService {
constructor(private h:HttpClient) { }
  url:string="http://localhost:9091/appointment";

  addAppointment(patientid:number,appointment:Appointment):Observable<any>{
    return this.h.post<any>(this.url+"/"+patientid+"/addAppointment",appointment,{responseType:'json'});
  }

  viewAppointments(patientName:string):Observable<any>{
    return this.h.get<any>(this.url+"/viewAppointmentsByname/"+patientName);
  }

  viewAppointment(appointmentId:number):Observable<any>{
    return this.h.get(this.url+"/viewAppointment/"+appointmentId);
  }

  updateAppointment(id:number,appointment:Appointment):Observable<any>{
    return this.h.put(this.url+"/"+id+"/updateAppointment",appointment,{responseType:'json'});
  }

  getAppointmentList(centerId:number,test:string,status:string):Observable<any>{
    return this.h.get(this.url+"/getAppointments/"+centerId+"/"+test+"/"+status);
  }
  removeAppointment(id:number):Observable<any>{
    return this.h.delete(this.url+"/removeAppointment/"+id);
  }

  getAllAppointments():Observable<any>{
    return this.h.get<any>(this.url+"/getAllApointments");
  }

  getgetAllApprovedApointments():Observable<any>{
    return this.h.get<any>(this.url+"/getAllApprovedApointments");
  }

  getAllPendingApointments():Observable<any>{
    return this.h.get<any>(this.url+"/getAllPendingApointments");
  }
}
