import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Patient } from 'src/assets/Patient';

@Injectable({
  providedIn: 'root'
})
export class PatientService {

 constructor(private h:HttpClient) { }
  url:string="http://localhost:9091/patient";

  registerPatient(patient:Patient):Observable<any>{
    return this.h.post<any>(this.url+"/registerPatient",patient,{responseType:'json'});
  }

  getAllTestResult(patientUserName:String):Observable<any>{
    return this.h.get<any>(this.url+"/testresult/"+patientUserName);
  }

  updatePatientDetails(patient:Patient):Observable<any>{
    return this.h.put(this.url+"/modifyMapping",patient,{responseType:'json'});
  }

  viewPatient(patientUserName:string):Observable<any>{
    return this.h.get(this.url+"/viewPatient/"+patientUserName);
  }

  viewTestResult(TestresultId:number):Observable<any>{
    return this.h.get(this.url+"/viewTestResult/"+TestresultId);
  }

}
