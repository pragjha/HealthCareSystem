import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DiagnosticCenterService } from 'src/app/diagnostic-center.service';
import { DiagnosticCenter } from 'src/assets/DiagnosticCenter';

@Component({
  selector: 'app-add-center-to-appointment',
  templateUrl: './add-center-to-appointment.component.html',
  styleUrls: ['./add-center-to-appointment.component.css']
})
export class AddCenterToAppointmentComponent implements OnInit {
  center:DiagnosticCenter=new DiagnosticCenter();
  appointmentid:number;

  constructor(private s:DiagnosticCenterService,private router:ActivatedRoute,private r:Router) { 
    this.appointmentid=parseInt(this.router.snapshot.paramMap.get('id'));
  }

  ngOnInit(): void {
  }

  serchCenter():void{
    this.s.getDiagnosticCenter(this.center.name).subscribe(c=>this.center=c);
  }

  addCenter():void{
    this.s.addCenterToAnAppointment(this.center,this.appointmentid).subscribe(c=>this.center=c);
    this.r.navigate(["/viewAllAppointments"]);
  }
}
