import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddCenterToAppointmentComponent } from './add-center-to-appointment.component';

describe('AddCenterToAppointmentComponent', () => {
  let component: AddCenterToAppointmentComponent;
  let fixture: ComponentFixture<AddCenterToAppointmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddCenterToAppointmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddCenterToAppointmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
