import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewAllAppointmentsComponent } from './view-all-appointments/view-all-appointments.component';
import { AddAppointmentComponent } from './add-appointment/add-appointment.component';
import { AddCenterToAppointmentComponent } from './add-center-to-appointment/add-center-to-appointment.component';
import { FormsModule } from '@angular/forms';
import { AddTestToAppointmentComponent } from './add-test-to-appointment/add-test-to-appointment.component';
import { ViewAllDetailsComponent } from './view-all-details/view-all-details.component';



@NgModule({
  declarations: [ViewAllAppointmentsComponent, AddAppointmentComponent, AddCenterToAppointmentComponent, AddTestToAppointmentComponent, ViewAllDetailsComponent],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports:[
    ViewAllAppointmentsComponent,
    AddAppointmentComponent,
    AddCenterToAppointmentComponent,
    AddTestToAppointmentComponent
  ]
})
export class AppointmentModule { }
