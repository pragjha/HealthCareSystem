import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppointmentService } from 'src/app/appointment.service';
import { Appointment } from 'src/assets/Appointment';

@Component({
  selector: 'app-view-all-appointments',
  templateUrl: './view-all-appointments.component.html',
  styleUrls: ['./view-all-appointments.component.css']
})
export class ViewAllAppointmentsComponent implements OnInit {
 appointment:Appointment=new Appointment();
 appointmnets:Appointment[]=[];
  approveflag:boolean =false;
  rejectflag:boolean=false;
  approvedAppointments:Appointment[]=[];
  pendingAppointments:Appointment[]=[];
  constructor(private s:AppointmentService,private r:Router) {
    this.s.getAllAppointments().subscribe(a=>this.appointmnets=a);
    this.s.getgetAllApprovedApointments().subscribe(a=>this.approvedAppointments=a);
   }

  ngOnInit(): void {
  }
  checkApporoved(a:Appointment):boolean{
    for(let ap of this.approvedAppointments){
      if(a.id==ap.id){
        return true;
      }
    }
  }
  checkCenter(a:Appointment):boolean{
    return a.diagnosticCenter==null?false:true;
  }
  onApprove(a:Appointment):void{
    this.approveflag=true;
    a.approvalStatus="Approved";
    this.s.updateAppointment(a.patient.patientid,a).subscribe(a=>console.log(a));
    window.location.reload();
  }
  onReject(a:Appointment):void{
    this.s.removeAppointment(a.id).subscribe(a=>this.appointment=a);
    window.location.reload();
  }

  addCenter(a:Appointment):void{
    this.r.navigate(["/addCenterToAppointment",a.id]);
  }
  addTest(a:Appointment):void{
    this.r.navigate(["/addTestToAppointment",a.id]);
  }
  viewDetails(a:Appointment):void{
    this.r.navigate(["/viewAppointmentDetails",a.id]);
  }
  addTestResult(a:Appointment):void{
    this.r.navigate(["/addTestResult",a.id]);
  }
}
