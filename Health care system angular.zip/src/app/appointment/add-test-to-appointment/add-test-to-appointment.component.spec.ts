import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddTestToAppointmentComponent } from './add-test-to-appointment.component';

describe('AddTestToAppointmentComponent', () => {
  let component: AddTestToAppointmentComponent;
  let fixture: ComponentFixture<AddTestToAppointmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddTestToAppointmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddTestToAppointmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
