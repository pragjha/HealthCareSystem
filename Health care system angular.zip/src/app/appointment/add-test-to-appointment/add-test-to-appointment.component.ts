import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DiagnosticTestService } from 'src/app/diagnostic-test.service';
import { DiagnosticTest } from 'src/assets/DiagnosticTest';
import {Location} from '@angular/common';

@Component({
  selector: 'app-add-test-to-appointment',
  templateUrl: './add-test-to-appointment.component.html',
  styleUrls: ['./add-test-to-appointment.component.css']
})
export class AddTestToAppointmentComponent implements OnInit {
  test:DiagnosticTest=new DiagnosticTest();
  id:number;
  constructor(private s:DiagnosticTestService,private r:Router,private route:ActivatedRoute,private location:Location) {
    this.id=parseInt(this.route.snapshot.paramMap.get("id"));
   }

  ngOnInit(): void {
  }
  addTest():void{
    this.s.addNewTestToAppointment(this.id,this.test).subscribe(t=>this.test=t);
    this.location.back();
  }
}
