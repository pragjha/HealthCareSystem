import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AppointmentService } from 'src/app/appointment.service';
import { DiagnosticTestService } from 'src/app/diagnostic-test.service';
import { TestResultService } from 'src/app/test-result.service';
import { TestService } from 'src/app/test.service';
import { Appointment } from 'src/assets/Appointment';
import { DiagnosticTest } from 'src/assets/DiagnosticTest';
import { TestResult } from 'src/assets/TestResult';

@Component({
  selector: 'app-view-all-details',
  templateUrl: './view-all-details.component.html',
  styleUrls: ['./view-all-details.component.css']
})
export class ViewAllDetailsComponent implements OnInit {
  appointment:Appointment=new Appointment();
  test:DiagnosticTest=new DiagnosticTest();
  id:number;
  result:TestResult=new TestResult();
  constructor(private s:AppointmentService,private r:Router,private route:ActivatedRoute
    ,private t:DiagnosticTestService,private ts:TestService,private tr:TestResultService) { 
    this.id=parseInt(this.route.snapshot.paramMap.get("id"));
    this.s.viewAppointment(this.id).subscribe(a=>this.appointment=a);
    this.ngOnInit();
  }

  ngOnInit(): void {
  }

  modifyTest(test:DiagnosticTest):void{
    this.r.navigate(["/modifyTest",test.id]);
  }

  deleteTest(test:DiagnosticTest):void{
    this.ts.removeTest(test.id).subscribe(a=>this.deleteTest=a);
    window.location.reload();
  }

  addTest():void{
    this.r.navigate(["/addTestToAppointment",this.appointment.id]);
  }
  goBack():void{
    this.r.navigate(["/viewAllAppointments"]);
  }
  modifyResult(d:TestResult):void{
    this.r.navigate(["/modifyTestResult",d.id]);
  }
  deleteResult(d:TestResult):void{
    this.tr.removeTestResult(d.id).subscribe(t=>this.result=t);
    window.location.reload();
  }
  addResult():void{
    this.r.navigate(["/addTestResult",this.appointment.id]);
  }
}
