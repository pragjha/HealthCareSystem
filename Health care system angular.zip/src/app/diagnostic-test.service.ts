import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DiagnosticTest } from 'src/assets/DiagnosticTest';

@Injectable({
  providedIn: 'root'
})
export class DiagnosticTestService {

  url:string="http://localhost:9091/diagnostictest";

  constructor(private h:HttpClient) { }

  getAllTest():Observable<any>{
    return this.h.get<any>(this.url+"/getAllTests");
  }

  addNewTestToAppointment(id:number,t:DiagnosticTest):Observable<any>{
    return this.h.post(this.url+"/"+id+"/addTest",t,{responseType:'json'});
  }

  getTestsOfDiagnosticCenter(id:number):Observable<any>{
    return this.h.get<any>(this.url+"/getTests/"+id);
  }

  updateTestDetail(t:DiagnosticTest):Observable<any>{
    return this.h.put(this.url+"/updateTests",t,{responseType:'json'});
  }

  removeTestFromDiagnosticCenter(id:number,testid:number):Observable<any>{
    return this.h.delete(this.url+"/removeTest/"+id+"/"+testid);
  }
}
