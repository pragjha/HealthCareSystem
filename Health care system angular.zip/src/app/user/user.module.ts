import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginUserComponent } from './login-user/login-user.component';
import { FormsModule } from '@angular/forms';
import { SigninUserComponent } from './signin-user/signin-user.component';



@NgModule({
  declarations: [LoginUserComponent, SigninUserComponent],
  imports: [
    CommonModule,FormsModule
  ],exports:[
    LoginUserComponent,SigninUserComponent
  ]
})
export class UserModule { }
