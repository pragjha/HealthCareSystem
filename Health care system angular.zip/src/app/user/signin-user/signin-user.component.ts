import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/user.service';
import { User } from 'src/assets/User';

@Component({
  selector: 'app-signin-user',
  templateUrl: './signin-user.component.html',
  styleUrls: ['./signin-user.component.css']
})
export class SigninUserComponent implements OnInit {

  user:User=new User();
  constructor(private s:UserService,private r:Router) { }

  ngOnInit(): void {
  }
  onClick():void{
    let us:User=new User();
    this.s.addUser(this.user).subscribe(u=>{
      this.user=u;
      if(u.role=="Patient"){
        this.r.navigate(["/viewAppointmentsOfPatient"]);
      }else{
        this.r.navigate(["/viewAllAppointments"]);
      }
    });
  }
  onLogin():void{
    this.r.navigate(["/login"]);
  }
}
