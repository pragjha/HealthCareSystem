import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/user.service';
import { User } from 'src/assets/User';

@Component({
  selector: 'app-login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.component.css']
})
export class LoginUserComponent implements OnInit {

  user:User=new User();
  constructor(private s:UserService,private r:Router) { }

  ngOnInit(): void {
  }
  onClick():void{
    let us:User=new User();
    this.s.validateUser(this.user.username,this.user.password).subscribe(u=>{
      if(u!=null){
        if(u.role=="Patient"){
        this.r.navigate(["/viewAppointmentsOfPatient"]);
        }else{
          this.r.navigate(["/viewAllAppointments"]);
        }
      }
    },(err:Response)=>{
      if(err){
        alert(err['error'].message);
        this.r.navigate([""]);
      }
    })
  }
}
