import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DiagnosticCenterService } from 'src/app/diagnostic-center.service';
import { DiagnosticCenter } from 'src/assets/DiagnosticCenter';
import {Location} from '@angular/common';

@Component({
  selector: 'app-modify-center',
  templateUrl: './modify-center.component.html',
  styleUrls: ['./modify-center.component.css']
})
export class ModifyCenterComponent implements OnInit {
  center:DiagnosticCenter=new DiagnosticCenter();
  id:number;
  constructor(private c:DiagnosticCenterService,private r:Router,private route:ActivatedRoute,private location:Location) {
    this.id=parseInt(this.route.snapshot.paramMap.get("id"));
    this.c.getDiagnosticCenterById(this.id).subscribe(a=>this.center=a);
   }

  ngOnInit(): void {
  }

  modifyCenter():void{
    this.c.updateDiagnosticCenter(this.center).subscribe(a=>this.center=a);
    this.location.back();
  }
}
