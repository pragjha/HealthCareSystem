import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DiagnosticCenterService } from 'src/app/diagnostic-center.service';
import { DiagnosticCenter } from 'src/assets/DiagnosticCenter';

@Component({
  selector: 'app-add-new-center',
  templateUrl: './add-new-center.component.html',
  styleUrls: ['./add-new-center.component.css']
})
export class AddNewCenterComponent implements OnInit {
  center:DiagnosticCenter=new DiagnosticCenter();
  constructor(private s:DiagnosticCenterService,private r:Router) { }

  ngOnInit(): void {
  }

  addCenter():void{
    this.s.addCenter(this.center).subscribe(c=>this.center=c);
    this.r.navigate(["/viewAllDiagnosticCenters"]);
  }
}
