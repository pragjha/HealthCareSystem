import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DiagnosticCenterService } from 'src/app/diagnostic-center.service';
import { DiagnosticTestService } from 'src/app/diagnostic-test.service';
import { TestService } from 'src/app/test.service';
import { DiagnosticCenter } from 'src/assets/DiagnosticCenter';
import { DiagnosticTest } from 'src/assets/DiagnosticTest';

@Component({
  selector: 'app-view-all-diagnostic-centers',
  templateUrl: './view-all-diagnostic-centers.component.html',
  styleUrls: ['./view-all-diagnostic-centers.component.css']
})
export class ViewAllDiagnosticCentersComponent implements OnInit {

  centers:DiagnosticCenter[]=[];


  constructor(private s:DiagnosticCenterService,private t:DiagnosticTestService,private ts:TestService,private r:Router) {
    this.s.getAllDiagnosticCenters().subscribe(a=>this.centers=a);
   }
  ngOnInit(): void {
    
  }

  showTests(dc:DiagnosticCenter):void{
    this.r.navigate(["/viewAllTest",dc.id]);
  }

  modifycenter(dc:DiagnosticCenter):void{
    this.r.navigate(["/modifyCenter",dc.id]);
  }

  deleteCenter(dc:DiagnosticCenter):void{
    for(let t of dc.tests){
      this.t.removeTestFromDiagnosticCenter(dc.id,t.id).subscribe();
      this.ts.removeTest(t.id).subscribe();
    }
    this.s.removeDiagnosticCenter(dc.id).subscribe(a=>this.deleteCenter=a);
    window.location.reload();
  }

  addCenter():void{
    this.r.navigate(["/addDiagnosticCenter"]);
  }
}
