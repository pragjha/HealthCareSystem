import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAllDiagnosticCentersComponent } from './view-all-diagnostic-centers.component';

describe('ViewAllDiagnosticCentersComponent', () => {
  let component: ViewAllDiagnosticCentersComponent;
  let fixture: ComponentFixture<ViewAllDiagnosticCentersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAllDiagnosticCentersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAllDiagnosticCentersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
