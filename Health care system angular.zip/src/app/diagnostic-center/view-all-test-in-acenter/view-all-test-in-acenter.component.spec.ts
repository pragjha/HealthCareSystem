import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAllTestInACenterComponent } from './view-all-test-in-acenter.component';

describe('ViewAllTestInACenterComponent', () => {
  let component: ViewAllTestInACenterComponent;
  let fixture: ComponentFixture<ViewAllTestInACenterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAllTestInACenterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAllTestInACenterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
