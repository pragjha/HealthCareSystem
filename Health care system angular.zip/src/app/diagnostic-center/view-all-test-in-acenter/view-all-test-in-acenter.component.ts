import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DiagnosticTestService } from 'src/app/diagnostic-test.service';
import { TestService } from 'src/app/test.service';
import { DiagnosticTest } from 'src/assets/DiagnosticTest';

@Component({
  selector: 'app-view-all-test-in-acenter',
  templateUrl: './view-all-test-in-acenter.component.html',
  styleUrls: ['./view-all-test-in-acenter.component.css']
})
export class ViewAllTestInACenterComponent implements OnInit {
  diagnostictests:DiagnosticTest[]=[];
  centerId:number;
  test:DiagnosticTest=new DiagnosticTest();
  constructor(private s:DiagnosticTestService,private r:Router,private router:ActivatedRoute,private t:TestService) { 
    this.centerId=parseInt(this.router.snapshot.paramMap.get("id"));
    this.s.getTestsOfDiagnosticCenter(this.centerId).subscribe(tests=>this.diagnostictests=tests);
  }

  ngOnInit(): void {
  }

  goBack():void{
    this.r.navigate(["/viewAllDiagnosticCenters"]);
  }
}
