import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewAllDiagnosticCentersComponent } from './view-all-diagnostic-centers/view-all-diagnostic-centers.component';
import { ViewAllTestInACenterComponent } from './view-all-test-in-acenter/view-all-test-in-acenter.component';
import { DiagnosticTestModule } from '../diagnostic-test/diagnostic-test.module';
import { ModifyCenterComponent } from './modify-center/modify-center.component';
import { FormsModule } from '@angular/forms';
import { AddNewCenterComponent } from './add-new-center/add-new-center.component';



@NgModule({
  declarations: [ViewAllDiagnosticCentersComponent, ViewAllTestInACenterComponent, ModifyCenterComponent, AddNewCenterComponent],
  imports: [
    CommonModule,
    DiagnosticTestModule,
    FormsModule,
  ],
  exports:[
    ViewAllDiagnosticCentersComponent,ViewAllTestInACenterComponent,ModifyCenterComponent,AddNewCenterComponent
  ]
})
export class DiagnosticCenterModule { }
