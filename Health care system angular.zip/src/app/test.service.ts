import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DiagnosticTest } from 'src/assets/DiagnosticTest';

@Injectable({
  providedIn: 'root'
})
export class TestService {

  url:string="http://localhost:9091/test";
  
  constructor(private h:HttpClient) { }
    addTest( test:DiagnosticTest):Observable<any>{
      return this.h.post<any>(this.url+"/addTest/",test,{responseType:'json'});
    }

    updateTest(test:DiagnosticTest):Observable<any>{
      return this.h.put(this.url+"/updateTest/",test,{responseType:'json'});
    }

    removeTest(id:number):Observable<any>{
      return this.h.delete(this.url+"/removeTest/"+id);
    }

    viewAllTest(criteria:String ):Observable<any>{
      return this.h.get(this.url+"/viewAllTest/"+criteria);
    }

    getTestById(id:number):Observable<any>{
      return this.h.get<any>(this.url+"/getTest/"+id);
    }
}
