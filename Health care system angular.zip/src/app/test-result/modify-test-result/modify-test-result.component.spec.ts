import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifyTestResultComponent } from './modify-test-result.component';

describe('ModifyTestResultComponent', () => {
  let component: ModifyTestResultComponent;
  let fixture: ComponentFixture<ModifyTestResultComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ModifyTestResultComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ModifyTestResultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
