import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { TestResultService } from 'src/app/test-result.service';
import { TestResult } from 'src/assets/TestResult';
import {Location} from '@angular/common';

@Component({
  selector: 'app-modify-test-result',
  templateUrl: './modify-test-result.component.html',
  styleUrls: ['./modify-test-result.component.css']
})
export class ModifyTestResultComponent implements OnInit {
  testResult:TestResult=new TestResult();
  id:number;
  constructor(private s:TestResultService,private r:Router,private route:ActivatedRoute,private location:Location) {
    this.id=parseInt(this.route.snapshot.paramMap.get("id"));
    this.s.getResultById(this.id).subscribe(a=>this.testResult=a);
   }

  ngOnInit(): void {
  }
  modifyTestResult():void{
    this.s.updateTestResult(this.testResult).subscribe(t=>this.testResult=t);
    this.location.back();
  }
}
