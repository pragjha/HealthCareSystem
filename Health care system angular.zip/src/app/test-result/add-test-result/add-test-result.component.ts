import {Location} from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TestResultService } from 'src/app/test-result.service';
import { TestResult } from 'src/assets/TestResult';

@Component({
  selector: 'app-add-test-result',
  templateUrl: './add-test-result.component.html',
  styleUrls: ['./add-test-result.component.css']
})
export class AddTestResultComponent implements OnInit {
  testResult:TestResult=new TestResult();
  id:number;
  constructor(private s:TestResultService,private r:Router,private route:ActivatedRoute,private location:Location) {
    this.id=parseInt(this.route.snapshot.paramMap.get("id"));
   }

  ngOnInit(): void {
  }

  addTestResult():void{
    this.s.addTestResult(this.id,this.testResult).subscribe(t=>this.testResult=t);
    this.location.back();
  }
}
