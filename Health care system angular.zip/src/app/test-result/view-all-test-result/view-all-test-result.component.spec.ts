import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAllTestResultComponent } from './view-all-test-result.component';

describe('ViewAllTestResultComponent', () => {
  let component: ViewAllTestResultComponent;
  let fixture: ComponentFixture<ViewAllTestResultComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAllTestResultComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAllTestResultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
