import { Component, OnInit } from '@angular/core';
import { TestResultService } from 'src/app/test-result.service';
import { TestResult } from 'src/assets/TestResult';

@Component({
  selector: 'app-view-all-test-result',
  templateUrl: './view-all-test-result.component.html',
  styleUrls: ['./view-all-test-result.component.css']
})
export class ViewAllTestResultComponent implements OnInit {
  results:TestResult[]=[];
  constructor(private s:TestResultService) {
    this.s.getAllTestResults().subscribe(r=>this.results=r);
   }

  ngOnInit(): void {
  }


}
