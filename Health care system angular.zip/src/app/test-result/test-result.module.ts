import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddTestResultComponent } from './add-test-result/add-test-result.component';
import { FormsModule } from '@angular/forms';
import { ModifyTestResultComponent } from './modify-test-result/modify-test-result.component';
import { ViewAllTestResultComponent } from './view-all-test-result/view-all-test-result.component';



@NgModule({
  declarations: [AddTestResultComponent, ModifyTestResultComponent, ViewAllTestResultComponent],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports:[
    AddTestResultComponent,ModifyTestResultComponent,ViewAllTestResultComponent
  ]
})
export class TestResultModule { }
