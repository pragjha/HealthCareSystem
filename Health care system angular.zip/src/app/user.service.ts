import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from 'src/assets/User';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  url:string="http://localhost:9091/user";

  constructor(private h:HttpClient) { }
  validateUser( username:String, password:String ):Observable<any>{
    return this.h.get(this.url+"/validateUser/"+username+"/"+password);
  }

  addUser( user:User):Observable<any>{
    return this.h.post(this.url+"/addUser",user,{responseType:'json'});
  }
}
