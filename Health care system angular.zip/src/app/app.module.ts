import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AppointmentModule } from './appointment/appointment.module';
import { DiagnosticCenterModule } from './diagnostic-center/diagnostic-center.module';
import { DiagnosticTestModule } from './diagnostic-test/diagnostic-test.module';
import { PatientModule } from './patient/patient.module';
import { TestResultModule } from './test-result/test-result.module';
import { UserModule } from './user/user.module';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AppointmentModule,
    DiagnosticCenterModule,
    DiagnosticTestModule,
    PatientModule,
    TestResultModule,
    UserModule,
    FormsModule,
    HttpClientModule,
    RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
