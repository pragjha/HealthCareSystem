import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewAllTestResultsByPatientComponent } from './view-all-test-results-by-patient/view-all-test-results-by-patient.component';
import { RegisterPatientComponent } from './register-patient/register-patient.component';
import { FormsModule } from '@angular/forms';
import { BookAppointmentForAPatientComponent } from './book-appointment-for-apatient/book-appointment-for-apatient.component';
import { ViewAppointsmentsOfAPatientComponent } from './view-appointsments-of-apatient/view-appointsments-of-apatient.component';



@NgModule({
  declarations: [ViewAllTestResultsByPatientComponent, RegisterPatientComponent, BookAppointmentForAPatientComponent, ViewAppointsmentsOfAPatientComponent],
  imports: [
    CommonModule,FormsModule
  ],
  exports:[
    ViewAllTestResultsByPatientComponent, RegisterPatientComponent,BookAppointmentForAPatientComponent,ViewAppointsmentsOfAPatientComponent
  ]
})
export class PatientModule { }
