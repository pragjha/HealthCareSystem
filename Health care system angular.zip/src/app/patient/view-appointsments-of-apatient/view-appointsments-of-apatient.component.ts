import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppointmentService } from 'src/app/appointment.service';
import { Appointment } from 'src/assets/Appointment';

@Component({
  selector: 'app-view-appointsments-of-apatient',
  templateUrl: './view-appointsments-of-apatient.component.html',
  styleUrls: ['./view-appointsments-of-apatient.component.css']
})
export class ViewAppointsmentsOfAPatientComponent implements OnInit {
  name:string;
  approvedAppointments:Appointment[]=[];
  appointments:Appointment[]=[];
  flag:boolean=false;
  constructor(private s:AppointmentService,private r:Router) {
    this.s.getgetAllApprovedApointments().subscribe(a=>this.approvedAppointments=a);
   }

  ngOnInit(): void {
  }
  showAppointments():void{
    this.s.viewAppointments(this.name).subscribe(a=>this.appointments=a,(err:Response)=>{
      if(err)
      alert(err['error'].message);
    });
  }
  checkApprroved(a:Appointment):boolean{
    for(let ap of this.approvedAppointments){
      if(ap.id==a.id){
        return true;
      }
    }
  }
  registerPatient():void{
    this.r.navigate(["/registerPatient"]);
  }
  addAppointment():void{
    this.r.navigate(["/bookAppointment",this.name]);
  }
  viewTestResult():void{
    this.r.navigate(["/viewTestResult"]);
  }
  logout():void{
    this.r.navigate([""]);
  }
}
