import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAppointsmentsOfAPatientComponent } from './view-appointsments-of-apatient.component';

describe('ViewAppointsmentsOfAPatientComponent', () => {
  let component: ViewAppointsmentsOfAPatientComponent;
  let fixture: ComponentFixture<ViewAppointsmentsOfAPatientComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAppointsmentsOfAPatientComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAppointsmentsOfAPatientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
