import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PatientService } from 'src/app/patient.service';
import { TestResultService } from 'src/app/test-result.service';
import { Patient } from 'src/assets/Patient';
import {TestResult } from 'src/assets/TestResult';

@Component({
  selector: 'app-view-all-test-results-by-patient',
  templateUrl: './view-all-test-results-by-patient.component.html',
  styleUrls: ['./view-all-test-results-by-patient.component.css']
})
export class ViewAllTestResultsByPatientComponent implements OnInit {
  name:string;
  patient:Patient=new Patient();
  results:TestResult[]=[];
  constructor(private p:PatientService,private s:TestResultService,private r:Router) {
   }

  ngOnInit(): void {
  }

  showResults():void{
    this.p.viewPatient(this.name).subscribe(p=>{
      this.patient=p;
      this.s.viewResultByPatient(this.patient.patientid).subscribe(t=>this.results=t,
        (err:Response)=>{
          if(err){
            this.results=null;
              alert(err['error'].message);
          }
        });
    });
    
  }
  logout():void{
    this.r.navigate([""]);
  }
}
