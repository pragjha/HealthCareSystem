import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAllTestResultsByPatientComponent } from './view-all-test-results-by-patient.component';

describe('ViewAllTestResultsByPatientComponent', () => {
  let component: ViewAllTestResultsByPatientComponent;
  let fixture: ComponentFixture<ViewAllTestResultsByPatientComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAllTestResultsByPatientComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAllTestResultsByPatientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
