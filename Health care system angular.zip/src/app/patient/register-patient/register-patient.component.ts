import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PatientService } from 'src/app/patient.service';
import { Patient } from 'src/assets/Patient';

@Component({
  selector: 'app-register-patient',
  templateUrl: './register-patient.component.html',
  styleUrls: ['./register-patient.component.css']
})
export class RegisterPatientComponent implements OnInit {
  patient:Patient=new Patient();
  constructor(private s:PatientService,private r:Router) { }

  ngOnInit(): void {
  }
  addPatient():void{
    this.s.registerPatient(this.patient).subscribe(p=>{
      this.patient=p;
      this.r.navigate(["/bookAppointment",p.name]);
    });
  }
  logout():void{
    this.r.navigate([""]);
  }
}
