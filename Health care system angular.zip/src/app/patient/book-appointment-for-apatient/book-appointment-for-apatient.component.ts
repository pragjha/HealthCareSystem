import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AppointmentService } from 'src/app/appointment.service';
import { PatientService } from 'src/app/patient.service';
import { Appointment } from 'src/assets/Appointment';
import { Patient } from 'src/assets/Patient';

@Component({
  selector: 'app-book-appointment-for-apatient',
  templateUrl: './book-appointment-for-apatient.component.html',
  styleUrls: ['./book-appointment-for-apatient.component.css']
})
export class BookAppointmentForAPatientComponent implements OnInit {
  name:string;
  patient:Patient=new Patient();
  appointment:Appointment=new Appointment();
  constructor(private s:PatientService,private aps:AppointmentService,private r:Router,private router:ActivatedRoute) {
    this.name=this.router.snapshot.paramMap.get("id");
    this.s.viewPatient(this.name).subscribe(p=>this.patient=p);
   }

  ngOnInit(): void {
  }
  bookAppointment():void{
    this.appointment.approvalStatus="Pending";
    this.aps.addAppointment(this.patient.patientid,this.appointment).subscribe(a=>this.appointment=a);
    this.r.navigate(["/viewAppointmentsOfPatient"]);
  }
  logout():void{
    this.r.navigate([""]);
  }
}
