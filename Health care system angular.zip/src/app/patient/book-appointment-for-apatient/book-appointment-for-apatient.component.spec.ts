import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookAppointmentForAPatientComponent } from './book-appointment-for-apatient.component';

describe('BookAppointmentForAPatientComponent', () => {
  let component: BookAppointmentForAPatientComponent;
  let fixture: ComponentFixture<BookAppointmentForAPatientComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BookAppointmentForAPatientComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BookAppointmentForAPatientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
