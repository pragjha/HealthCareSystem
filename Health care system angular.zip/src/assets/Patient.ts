import { Appointment } from "./Appointment";

export class Patient{
    public patientid:number;
    public name:string;
    public phoneNo:string;
    public age:number;
    public gender:string;
    public appointments:Appointment[];
}