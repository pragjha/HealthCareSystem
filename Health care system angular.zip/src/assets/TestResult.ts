import { Appointment } from "./Appointment";

export class TestResult {
     
    public id: number;
    public testReading :number;
    public condition: string;
    public appoinment:Appointment;
}