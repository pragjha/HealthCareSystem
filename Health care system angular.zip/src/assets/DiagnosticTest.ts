import { DiagnosticCenter } from "./DiagnosticCenter";

export class DiagnosticTest{
    id:number;
    testName:string;
    testPrice:number;
    normalValue:String;
    units:String;
    diagnosticCenters:DiagnosticCenter[]=[];
}
