import { DiagnosticCenter } from "./DiagnosticCenter";
import { DiagnosticTest } from "./DiagnosticTest";
import { Patient } from "./Patient";
import { TestResult } from "./TestResult";

export class Appointment{
    public id: number;
    public appointmentDate: Date;
    public approvalStatus: string="Pending";
    public diagnosticTests: DiagnosticTest[]=[];
    public patient:Patient;
    public diagnosticCenter: DiagnosticCenter;
    public testResult: TestResult[]=[];


}