import { DiagnosticTest } from "./DiagnosticTest";

export class DiagnosticCenter{
    id:number;
    public name:string;
    public contactNo:string;
    public address:string;
    public contactEmail:string;
    public servicesOffered:string[]=[];
    public tests:DiagnosticTest[]=[];
}